package com.cg.pp.service;

import java.util.List;
import com.cg.pp.bean.AccountHolder;
import com.cg.pp.bean.Transactions;
import com.cg.pp.dao.AccountDao;
import com.cg.pp.dao.IAccountDao;
import com.cg.pp.exception.AccountNotExistException;
import com.cg.pp.exception.FieldCannotBeNullException;
import com.cg.pp.exception.MobileNumberAlreadyExistException;
import com.cg.pp.exception.NotEnoughBalanceException;

public class AccountSevice implements IAccountService{

	IAccountDao accountDao=null;
	public AccountSevice() {
		// TODO Auto-generated constructor stub
		accountDao = new AccountDao();
	}
	@Override
	public AccountHolder createAccount(String firstName, String lastName, String mobileNo, String gender, int age,
			double amount) throws FieldCannotBeNullException, MobileNumberAlreadyExistException {
		return accountDao.createAccount(firstName, lastName, mobileNo, gender, age, amount);
	}
	@Override
	public AccountHolder withdrawAmount(String mobileNo, double amount) throws NotEnoughBalanceException, AccountNotExistException {
		return accountDao.withdrawAmount(mobileNo, amount);
	}
	@Override
	public AccountHolder depositAmount(String mobileNo, double amount) throws AccountNotExistException {
		return accountDao.depositAmount(mobileNo, amount);
	}
	@Override
	public double showBalance(String mobileNo) throws AccountNotExistException {
		return accountDao.showBalance(mobileNo);
	}
	@Override
	public List<Transactions> printTtansaction(String mobileNo) {
		return accountDao.printTtansaction(mobileNo);
	}
	@Override
	public String fundTransfer(String senderMobileNo, String receiverMobileNo, double amount) throws AccountNotExistException, NotEnoughBalanceException {
		return accountDao.fundTransfer(senderMobileNo, receiverMobileNo, amount);
	}
	
	
}
