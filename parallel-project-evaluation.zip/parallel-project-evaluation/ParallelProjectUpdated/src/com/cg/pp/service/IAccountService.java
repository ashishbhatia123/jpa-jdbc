package com.cg.pp.service;

import java.util.List;
import com.cg.pp.bean.AccountHolder;
import com.cg.pp.bean.Transactions;
import com.cg.pp.exception.AccountNotExistException;
import com.cg.pp.exception.FieldCannotBeNullException;
import com.cg.pp.exception.MobileNumberAlreadyExistException;
import com.cg.pp.exception.NotEnoughBalanceException;

public interface IAccountService {

	public AccountHolder createAccount(String firstName,String lastName,String mobileNo,String gender,int age,double amount) throws FieldCannotBeNullException, MobileNumberAlreadyExistException;
	public AccountHolder withdrawAmount(String mobileNo,double amount) throws NotEnoughBalanceException, AccountNotExistException;
	public AccountHolder depositAmount(String mobileNo,double amount) throws AccountNotExistException;
	public double showBalance(String mobileNo) throws AccountNotExistException;
	public List<Transactions> printTtansaction(String mobileNo);
	public String fundTransfer(String senderMobileNo,String receiverMobileNo,double amount) throws AccountNotExistException, NotEnoughBalanceException;
	
}
