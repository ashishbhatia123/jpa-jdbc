package com.cg.pp.util;

import java.util.HashMap;
import java.util.Map;
import com.cg.pp.bean.AccountHolder;
import com.cg.pp.bean.Wallet;

public class CollectionUtil {

	private static Map<String,AccountHolder> account=new HashMap<String, AccountHolder>();
	
	static
	{
		account.put("7088559555",new AccountHolder("Akrati","Agrawal","Female",22,600));
		account.put("9876543210",new AccountHolder("Ramya","Gour","Female",21,500));
		account.put("7895167416",new AccountHolder("Shivangi","Tripathi","Female",22,1000));
		account.put("9450345042",new AccountHolder("Yashasvi","Vashishtha","Female",22,800));
		account.put("9452525749",new AccountHolder("Akku","Vashishtha","Male",22,200));
	}
	
	public Map<String, AccountHolder> getAccountDetails()
	{
		return account;
	}
}
