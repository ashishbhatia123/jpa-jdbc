package com.cg.pp.bean;

public class Wallet {

	private double balance;
	Transactions transaction;
	
	public Wallet() {
		super();
		transaction=new Transactions();
	}
	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	

	public Transactions getTransaction() {
		return transaction;
	}
	public void setTransaction(Transactions transaction) {
		this.transaction = transaction;
	}
	@Override
	public String toString() 
	{
		System.out.println("-----------------------------------------------------------------------");
		return "balance=" + balance;
	}
	
}
