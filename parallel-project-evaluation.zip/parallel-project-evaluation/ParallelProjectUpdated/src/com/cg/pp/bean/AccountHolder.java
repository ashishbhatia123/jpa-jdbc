package com.cg.pp.bean;

public class AccountHolder {

	private String firstName;
	private String lastName;
	private String gender;
	private int age;
	private Wallet wallet;
	
	public AccountHolder() {
		super();
	}

	public AccountHolder(String firstName, String lastName, String gender, int age,double amount) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.age = age;
		this.wallet = new Wallet();
		wallet.setBalance(amount);
	}
	public Wallet getWallet() {
		return wallet;
	}

	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() 
	{
		System.out.println("-----------------------------------------------------------------------");
		return "firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender +
				", age=" + age + ", wallet=" + wallet;
	}
	
}
