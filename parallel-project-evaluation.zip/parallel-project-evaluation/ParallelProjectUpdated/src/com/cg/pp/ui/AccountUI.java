package com.cg.pp.ui;

import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;
import com.cg.pp.bean.AccountHolder;
import com.cg.pp.bean.Transactions;
import com.cg.pp.exception.AccountNotExistException;
import com.cg.pp.exception.FieldCannotBeNullException;
import com.cg.pp.exception.MobileNumberAlreadyExistException;
import com.cg.pp.exception.NotEnoughBalanceException;
import com.cg.pp.service.AccountSevice;
import com.cg.pp.service.IAccountService;

public class AccountUI {
	
	public static void main(String ag[])
	{
		AccountHolder accountHolder=null;
		IAccountService service=new AccountSevice();
		Scanner scan=new Scanner(System.in);
		while(true)
		{
			System.out.println("------------------------------");
			System.out.println("1. Create Account\n2. Withdraw Amount\n3. Deposit "
					+ "Amount\n4. Show Balance\n5. Print Transaction\n6. Fund Transfer"
					+ "\n7. Exit\nEnter your choice \n");
			System.out.println("------------------------------");
			int choice= scan.nextInt();
			switch(choice)
			{
				case 1:{
					System.out.println("-------------------------------");
					System.out.println("Enter account holder first name");
					System.out.println("-------------------------------");
					scan.nextLine();
					String firstName=scan.nextLine();
					System.out.println("------------------------------");
					System.out.println("Enter account holder last name");
					System.out.println("------------------------------");
					String lastName=scan.nextLine();
					System.out.println("-------------------");
					System.out.println("Enter mobile number");
					System.out.println("-------------------");
					String mobileNo=scan.nextLine();
					while(!Pattern.matches("[789]{1}[0-9]{9}",mobileNo))
					{
						System.out.println("Wrong format of mobile number enter again");
						System.out.println("-------------------");
						mobileNo=scan.nextLine();
					}
					System.out.println("---------------------------");
					System.out.println("Enter account holder gender");
					System.out.println("---------------------------");
					String gender=scan.nextLine();
					System.out.println("------------------------");
					System.out.println("Enter account holder age");
					System.out.println("------------------------");
					int age=scan.nextInt();
					System.out.println("---------------------");
					System.out.println("Enter starting amount");
					System.out.println("---------------------");
					double amount=scan.nextDouble();
					try {
						accountHolder=service.createAccount(firstName,lastName,mobileNo,gender,age,amount);
					} catch (FieldCannotBeNullException | MobileNumberAlreadyExistException e) {
						e.printStackTrace();
					}
					System.out.println(accountHolder);
					System.out.println("-----------------------------------------------------------------------");
					break;
				}
				case 2:{
					System.out.println("---------------------------------------------------------");
					System.out.println("Enter the mobile number whose amount you want to withdraw");
					System.out.println("---------------------------------------------------------");
					scan.nextLine();
					String withdrawMobileNo=scan.nextLine();
					System.out.println("-------------------------------------");
					System.out.println("Enter the amount you want to withdraw");
					System.out.println("-------------------------------------");
					double withdrawAmount=scan.nextDouble();
					try {
						accountHolder=service.withdrawAmount(withdrawMobileNo,withdrawAmount);
					} catch (NotEnoughBalanceException | AccountNotExistException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("Your current Balance is" + accountHolder.getWallet().getBalance());
					System.out.println("-----------------------------------------------------------------------");
					break;
				}
				case 3:{
					System.out.println("--------------------------------------------------------");
					System.out.println("Enter the mobile number whose amount you want to deposit");
					System.out.println("--------------------------------------------------------");
					scan.nextLine();
					String depositMobileNo=scan.nextLine();
					System.out.println("------------------------------------");
					System.out.println("Enter the amount you want to deposit");
					System.out.println("------------------------------------");
					double depositAmount=scan.nextDouble();
					try {
						accountHolder=service.depositAmount(depositMobileNo,depositAmount);
					} catch (AccountNotExistException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("Your current balance is"+accountHolder.getWallet().getBalance());
					System.out.println("-----------------------------------------------------------------------");
					break;
				}
				case 4:{
					System.out.println("-------------------------------------------------------");
					System.out.println("Enter the mobile number whose balance you want to check");
					System.out.println("-------------------------------------------------------");
					scan.nextLine();
					String checkMobileNo=scan.nextLine();
					System.out.println("----------------------------------");
					try {
						System.out.println("Total balance is: "+service.showBalance(checkMobileNo));
					} catch (AccountNotExistException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("-----------------------------------------------------------------------");
					System.out.println("----------------------------------");
					break;
				}
				case 5:{
					System.out.println("--------------------------------------------------");
					System.out.println("Enter the mobile number whose transaction you want");
					System.out.println("--------------------------------------------------");
					scan.nextLine();
					String printMobileNo=scan.nextLine();
					List<Transactions> list=service.printTtansaction(printMobileNo);
					for(Transactions trans:list)
					{
						System.out.println(trans);
					}
					System.out.println("-----------------------------------------------------------------------");
					break;
				}
				case 6:{
					System.out.println("----------------------------");
					System.out.println("Enter the mobileNo of sender");
					System.out.println("----------------------------");
					scan.nextLine();
					String senderMobileNo=scan.nextLine();
					System.out.println("------------------------------");
					System.out.println("Enter the mobileNo of receiver");
					System.out.println("------------------------------");
					String receiverMobileNo=scan.nextLine();
					System.out.println("-------------------------------------");
					System.out.println("Enter the amount you want to transfer");
					System.out.println("-------------------------------------");
					double sendAmount=scan.nextDouble();
					System.out.println("-----------------------------------------------------------------------");
					try {
						System.out.println(service.fundTransfer(senderMobileNo, receiverMobileNo, sendAmount));
					} catch (AccountNotExistException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (NotEnoughBalanceException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("-----------------------------------------------------------------------");
					break;
				}
				case 7:{
					scan.close();
					System.out.println("*******************");
					System.out.println("Thanks for visiting");
					System.out.println("*******************");
					System.exit(0);
					break;
				}
			}
		}
	}
}