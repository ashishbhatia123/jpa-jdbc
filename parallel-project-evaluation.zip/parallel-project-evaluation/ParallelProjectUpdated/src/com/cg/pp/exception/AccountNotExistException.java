package com.cg.pp.exception;

public class AccountNotExistException extends Exception 
{
	public AccountNotExistException(String error)
	{
		super(error);
	}

}
