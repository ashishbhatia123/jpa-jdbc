package com.cg.pp.exception;

public class MobileNumberAlreadyExistException extends Exception{

	public MobileNumberAlreadyExistException(String message) {
		super(message);
	}

	
}
