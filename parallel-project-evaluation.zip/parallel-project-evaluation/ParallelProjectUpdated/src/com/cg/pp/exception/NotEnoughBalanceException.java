package com.cg.pp.exception;

public class NotEnoughBalanceException extends Exception 
{
	public NotEnoughBalanceException(String error)
	{
		super(error);
	}

}
