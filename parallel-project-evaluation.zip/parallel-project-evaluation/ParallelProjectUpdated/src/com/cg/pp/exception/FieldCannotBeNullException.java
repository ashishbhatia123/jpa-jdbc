package com.cg.pp.exception;

public class FieldCannotBeNullException extends Exception{

	public FieldCannotBeNullException(String message) {
		super(message);
	}
	
}
