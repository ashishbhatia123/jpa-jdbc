package com.cg.pp.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import com.cg.pp.bean.AccountHolder;
import com.cg.pp.bean.Transactions;
import com.cg.pp.dao.AccountDao;
import com.cg.pp.dao.IAccountDao;
import com.cg.pp.exception.AccountNotExistException;
import com.cg.pp.exception.FieldCannotBeNullException;
import com.cg.pp.exception.MobileNumberAlreadyExistException;
import com.cg.pp.exception.NotEnoughBalanceException;

public class AccountTesting {

	IAccountDao accountDao=new AccountDao();
	AccountHolder account;
	String result;

	/*
	 * CREATE ACCOUNT
	 * 1. When first name passed is null, it should throw exception 
	 * 2. When last name passed is null, it should throw exception
	 * 3. When mobile number passed is null, it should throw exception
	 * 4. When gender passed is null, it should throw exception 
	 */

	@Test(expected=com.cg.pp.exception.FieldCannotBeNullException.class)
	public void WhenFirstNamePassedIsNullThrowsException() throws FieldCannotBeNullException, MobileNumberAlreadyExistException
	{
		account=accountDao.createAccount(null, "XYX","9999999988", "Male",20,23000);
	}
	
	@Test(expected=com.cg.pp.exception.FieldCannotBeNullException.class)
	public void WhenLastNamePassedIsNullThrowsException() throws FieldCannotBeNullException, MobileNumberAlreadyExistException
	{
		account=accountDao.createAccount("ABC", null,"9999999988", "Male",20,23000);
	}
	
	@Test(expected=com.cg.pp.exception.FieldCannotBeNullException.class)
	public void WhenMobileNumberPassedIsNullThrowsException() throws FieldCannotBeNullException, MobileNumberAlreadyExistException
	{
		account=accountDao.createAccount("ABC", "XYX",null, "Male",20,23000);
	}
	
	@Test(expected=com.cg.pp.exception.FieldCannotBeNullException.class)
	public void WhenGenderPassedIsNullThrowsException() throws FieldCannotBeNullException, MobileNumberAlreadyExistException
	{
		account=accountDao.createAccount("ABC", "XYX","9999999988", null,20,23000);
	}
	
	//***********************************************************************************************************
	
	    /*
		 * Withdraw Amount
		 * 1. When WithdrawAmount With Appropriate Details, Withdraw amount Successfully
		 * 2. When Mobile Number Entered is not found/ Account does not exists, it should throw an exception
		 * 3. When balance is insufficient, it should throw Exception
		*/ 
	
		@Test()
		public void WhenCorrectDetailsEnteredItShouldWithdrawTheAmount() throws FieldCannotBeNullException, MobileNumberAlreadyExistException, NotEnoughBalanceException, AccountNotExistException 
		{
			boolean flag;
			account=accountDao.withdrawAmount("9876543210", 10);
			if(account==null)
			{
				flag=false;
			}
			flag=true;
			assertTrue(flag);
		}
		
		@Test(expected=com.cg.pp.exception.AccountNotExistException.class)
		public void WhenMobileNumberIsIncorrectItShouldWithdrawThrowException() throws FieldCannotBeNullException, MobileNumberAlreadyExistException, NotEnoughBalanceException, AccountNotExistException 
		{
			account=accountDao.withdrawAmount("9999998888",1000);
		}

		@Test(expected=com.cg.pp.exception.NotEnoughBalanceException.class)
		public void WhenBalanceIsInsufficientItShouldWithdrawThrowException() throws FieldCannotBeNullException, MobileNumberAlreadyExistException, NotEnoughBalanceException, AccountNotExistException 
		{
			account=accountDao.withdrawAmount("9876543210",1000);
		}
	
	//***********************************************************************************************************
	
		/*
		 * Deposit Amount
		 * 1. When Mobile Number Entered is not found/ Account does not exists, it should throw an exception
		 * 2. When Deposit Amount with Appropriate Details, deposit amount successfully
		 */
		
		@Test()
		public void WhenCorrectDetailsEnteredItShouldDepositAmountToWallet() throws AccountNotExistException, FieldCannotBeNullException, MobileNumberAlreadyExistException
		{
			
			account=accountDao.depositAmount("9450345042", 20);
			
		}
		
		@Test(expected=com.cg.pp.exception.AccountNotExistException.class)
		public void WhenPhoneNumberEnteredIsNotFound() throws AccountNotExistException, FieldCannotBeNullException, MobileNumberAlreadyExistException
		{
			account=accountDao.depositAmount("9999998888", 1000);
		}

		//***********************************************************************************************************
		
		/*
		 * Show Balance
		 * 1. When mobile number is correct it should show the balance
		 * 2. When Mobile Number Entered is not found/ Account does not exists, it should throw an exception
		 */
		
		
		@Test(expected=com.cg.pp.exception.AccountNotExistException.class)
		public void WhenMobileNumberIsIncorrectItShouldThrowException() throws FieldCannotBeNullException, MobileNumberAlreadyExistException, AccountNotExistException 
		{
			double balance;
			balance=accountDao.showBalance("999998999");
		}
		
		//***********************************************************************************************************
		
		/*
		 * Fund Transfer
		 * 1. When Details are correct It Should transfer Fund.
		 * 2. When remitter's or reciever's mobile number is incorrect, it should through exception.
		 * 3. When sender's mobile number is incorrect, it should through exception.
		 */
		
		@Test()
		public void WhenDetailsAreAppropriateFundShouldBeTransfered() throws FieldCannotBeNullException, MobileNumberAlreadyExistException, AccountNotExistException, NotEnoughBalanceException 
		{
			result=accountDao.fundTransfer("7088559555","7895167416", 2000);
			assertEquals("Fund successfully transferred",result);
		}
		
		@Test(expected= com.cg.pp.exception.AccountNotExistException.class)
		public void WhenReceiverPhoneNumberIsIncorrectItShouldThrowException() throws FieldCannotBeNullException, MobileNumberAlreadyExistException, AccountNotExistException, NotEnoughBalanceException 
		{
			
			result=accountDao.fundTransfer("7895167416","9989989988", 2000);
		}
		
		@Test(expected= com.cg.pp.exception.AccountNotExistException.class)
		public void WhenSenderPhoneNumberIsIncorrectItShouldThrowException() throws FieldCannotBeNullException, MobileNumberAlreadyExistException, AccountNotExistException, NotEnoughBalanceException 
		{
			result=accountDao.fundTransfer("9989989989","9876543210", 2000);
		}
		
}
