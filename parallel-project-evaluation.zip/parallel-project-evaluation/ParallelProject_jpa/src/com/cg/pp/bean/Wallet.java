package com.cg.pp.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Wallet 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int walletNo;
	@Column(name="balance",length=10)
	private double balance;
	@OneToMany(targetEntity=Transactions.class,cascade=CascadeType.ALL)
	private List<Transactions> listTransaction;
	
	public Wallet() {
		super();
		listTransaction=new ArrayList<Transactions>();
	}
	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	public int getWalletNo() {
		return walletNo;
	}
	public void setWalletNo(int walletNo) {
		this.walletNo = walletNo;
	}
	public List<Transactions> getListTransaction() {
		return listTransaction;
	}
	public void setListTransaction(List<Transactions> listTransaction) {
		this.listTransaction = listTransaction;
	}
	@Override
	public String toString() {
		return "Wallet [walletNo=" + walletNo + ", balance=" + balance + ", listTransaction=" + listTransaction + "]";
	}
	
}
