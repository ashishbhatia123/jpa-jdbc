package com.example.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.IAccountDao;
import com.example.bean.AccountHolder;
import com.example.bean.Transactions;

@Service
@Transactional
public class AccountSevice implements IAccountService{
	
	
	@Autowired
	IAccountDao accountDao;

	@Override
	public String createAccount(AccountHolder account) {
		return accountDao.createAccount(account);
		
	}
	
	 @Override 
	 public AccountHolder withdrawAmount(String mobileNo, double amount)
	 {return accountDao.withdrawAmount(mobileNo,amount); }
	  
	  @Override 
	  public AccountHolder depositAmount(String mobileNo, double amount)
	  {
		  return accountDao.depositAmount(mobileNo, amount); 
	  }
	  
	  @Override 
	  public double showBalance(String mobileNo)
	  { return accountDao.showBalance(mobileNo); }
	  
	  @Override 
	  public List<Transactions> printTtansaction(String mobileNo) {	  
		  return accountDao.printTtansaction(mobileNo);
	   }
	  
	  @Override public ArrayList<AccountHolder> fundTransfer(String senderMobileNo, String receiverMobileNo, double amount)
	  { 
	  return accountDao.fundTransfer(senderMobileNo, receiverMobileNo, amount); 
	  }
	  
	 	
}
