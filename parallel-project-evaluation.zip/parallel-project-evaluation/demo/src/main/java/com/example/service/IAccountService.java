package com.example.service;

import java.util.ArrayList;
import java.util.List;

import com.example.bean.AccountHolder;
import com.example.bean.Transactions;

public interface IAccountService {

	public String createAccount(AccountHolder account);
	
	 public AccountHolder withdrawAmount(String mobileNo,double amount) ;
	 public AccountHolder depositAmount(String mobileNo,double amount) ; 
	 public double showBalance(String mobileNo); 
	 public List<Transactions> printTtansaction(String mobileNo);
	 public ArrayList<AccountHolder> fundTransfer(String senderMobileNo,String receiverMobileNo,double amount);
	 
}
